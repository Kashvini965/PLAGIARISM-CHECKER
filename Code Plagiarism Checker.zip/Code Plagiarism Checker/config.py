"""
Configuration module for Code Plagiarism Checker
"""

import os


class Config:
    """Main configuration class"""

    # Flask settings
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    DEBUG = True
    TESTING = False

    # Upload configuration
    UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'uploads')
    MAX_CONTENT_LENGTH = 10 * 1024 * 1024  # 10MB max file size
    ALLOWED_EXTENSIONS = {
        'py', 'java', 'cpp', 'c', 'js', 'ts', 'html', 'css',
        'php', 'rb', 'go', 'rs', 'swift', 'kotlin', 'scala',
        'cs', 'vb', 'r', 'm', 'lua', 'pl', 'sh'
    }

    # Plagiarism detection settings
    PLAGIARISM_THRESHOLD = 0.70  # 70% similarity threshold
    MIN_TOKEN_LENGTH = 3  # Minimum token length for matching

    # Session configuration
    PERMANENT_SESSION_LIFETIME = 1800  # 30 minutes
    SESSION_REFRESH_EACH_REQUEST = True


class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True


class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'change-me-in-production'


class TestingConfig(Config):
    """Testing configuration"""
    TESTING = True
    UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'test_uploads')


# Export config
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}
