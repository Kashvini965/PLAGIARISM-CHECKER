"""
Main Flask application for Code Plagiarism Checker
"""

import os
import json
from flask import Flask, render_template, request, jsonify, send_file
from werkzeug.utils import secure_filename
from datetime import datetime

from config import Config
from src.file_parser import FileParser
from src.similarity_calculator import SimilarityCalculator
from src.report_generator import ReportGenerator
from src.project_analyzer import ProjectAnalyzer
from src.content_comparator import ContentComparator
from src.pdf_generator import PDFReportGenerator
from src.report_history import ReportHistory
from src.detailed_detector import DetailedDetector

# Initialize Flask app
app = Flask(__name__)
app.config.from_object(Config)

# Create necessary directories
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize modules
calculator = SimilarityCalculator()
project_analyzer = ProjectAnalyzer()
content_comparator = ContentComparator()
detailed_detector = DetailedDetector()
report_history = ReportHistory(os.path.join(app.config['UPLOAD_FOLDER'], 'reports_history'))


@app.route('/')
def index():
    """Home page"""
    return render_template('index.html')


@app.route('/api/upload', methods=['POST'])
def upload_files():
    """Handle file upload and comparison"""
    try:
        # Check if files are provided
        if 'file1' not in request.files or 'file2' not in request.files:
            return jsonify({'error': True, 'message': 'Two files are required'}), 400

        file1 = request.files['file1']
        file2 = request.files['file2']

        if file1.filename == '' or file2.filename == '':
            return jsonify({'error': True, 'message': 'Filenames cannot be empty'}), 400

        # Validate files
        valid1, msg1 = FileParser.validate_file(file1.filename)
        valid2, msg2 = FileParser.validate_file(file2.filename)

        if not (FileParser.is_supported(file1.filename) and FileParser.is_supported(file2.filename)):
            return jsonify({
                'error': True,
                'message': f'Unsupported file type. Supported: {", ".join(FileParser.SUPPORTED_EXTENSIONS)}'
            }), 400

        # Save files temporarily
        filename1 = secure_filename(file1.filename)
        filename2 = secure_filename(file2.filename)

        filepath1 = os.path.join(app.config['UPLOAD_FOLDER'], f"temp1_{filename1}")
        filepath2 = os.path.join(app.config['UPLOAD_FOLDER'], f"temp2_{filename2}")

        file1.save(filepath1)
        file2.save(filepath2)

        # Compare files
        result = calculator.compare_files(filepath1, filepath2)

        # Clean up temporary files
        try:
            os.remove(filepath1)
            os.remove(filepath2)
        except:
            pass

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': True, 'message': f'Error: {str(e)}'}), 500


@app.route('/api/compare-text', methods=['POST'])
def compare_text():
    """Compare two code snippets"""
    try:
        data = request.get_json()

        if not data:
            return jsonify({'error': True, 'message': 'No data provided'}), 400

        code1 = data.get('code1', '').strip()
        code2 = data.get('code2', '').strip()
        file1_name = data.get('file1_name', 'Code 1')
        file2_name = data.get('file2_name', 'Code 2')

        if not code1 or not code2:
            return jsonify({'error': True, 'message': 'Both code snippets are required'}), 400

        # Compare texts
        result = calculator.compare_text(code1, code2, file1_name, file2_name)

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': True, 'message': f'Error: {str(e)}'}), 500


@app.route('/api/report/<report_type>', methods=['POST'])
def generate_report(report_type):
    """Generate report in different formats"""
    try:
        data = request.get_json()

        if not data:
            return jsonify({'error': True, 'message': 'No comparison data provided'}), 400

        # Handle single file comparison reports
        if report_type == 'html':
            html_report = ReportGenerator.generate_html_report(data)
            return html_report, 200, {'Content-Type': 'text/html'}

        elif report_type == 'text':
            text_report = ReportGenerator.generate_text_report(data)
            return text_report, 200, {'Content-Type': 'text/plain'}

        elif report_type == 'json':
            json_report = ReportGenerator.generate_json_report(data)
            return jsonify(json_report)

        # Handle project reports
        elif report_type == 'project-html':
            html_report = ReportGenerator.generate_project_html_report(data)
            return html_report, 200, {'Content-Type': 'text/html'}

        elif report_type == 'project-text':
            text_report = ReportGenerator.generate_project_text_report(data)
            return text_report, 200, {'Content-Type': 'text/plain'}

        elif report_type == 'project-json':
            json_report = ReportGenerator.generate_project_json_report(data)
            return jsonify(json_report)

        else:
            return jsonify({'error': True, 'message': 'Invalid report type'}), 400

    except Exception as e:
        return jsonify({'error': True, 'message': f'Error: {str(e)}'}), 500


@app.route('/api/upload-project', methods=['POST'])
def upload_project():
    """Handle project zip file upload and analysis"""
    try:
        if 'project_file' not in request.files:
            return jsonify({'error': True, 'message': 'Project file is required'}), 400

        project_file = request.files['project_file']

        if project_file.filename == '':
            return jsonify({'error': True, 'message': 'Filename cannot be empty'}), 400

        # Only accept zip files
        if not project_file.filename.endswith('.zip'):
            return jsonify({
                'error': True,
                'message': 'Only ZIP files are supported. Please compress your project folder.'
            }), 400

        # Save project file temporarily
        filename = secure_filename(project_file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], f"project_{filename}")
        project_file.save(filepath)

        # Analyze project
        project_name, results = project_analyzer.extract_and_analyze_zip(filepath, app.config['UPLOAD_FOLDER'])

        # Generate statistics
        statistics = project_analyzer.calculate_project_statistics(results)

        # Prepare response
        response_data = {
            'project_name': project_name,
            'results': results,
            'statistics': statistics,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

        # Clean up temporary file
        try:
            os.remove(filepath)
        except:
            pass

        return jsonify(response_data)

    except Exception as e:
        return jsonify({'error': True, 'message': f'Error: {str(e)}'}), 500


@app.route('/project-report')
def project_report():
    """Project report page"""
    return render_template('project-report.html')


@app.route('/api/compare-detailed', methods=['POST'])
def compare_detailed():
    """Detailed content comparison with segments"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': True, 'message': 'No data provided'}), 400

        code1 = data.get('code1', '').strip()
        code2 = data.get('code2', '').strip()

        if not code1 or not code2:
            return jsonify({'error': True, 'message': 'Both code snippets are required'}), 400

        # Perform detailed comparison
        detailed_result = content_comparator.compare_content_detailed(code1, code2)
        segment_result = detailed_detector.detect_plagiarized_segments(code1, code2)

        return jsonify({
            'detailed_comparison': detailed_result,
            'segment_detection': segment_result
        })

    except Exception as e:
        return jsonify({'error': True, 'message': f'Error: {str(e)}'}), 500


@app.route('/api/generate-pdf-report', methods=['POST'])
def generate_pdf_report():
    """Generate PDF report"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': True, 'message': 'No data provided'}), 400

        report_type = data.get('report_type', 'comparison')

        if report_type == 'comparison':
            html_content = PDFReportGenerator.generate_pdf_report(data)
        elif report_type == 'project':
            html_content = PDFReportGenerator.generate_project_pdf_report(data)
        else:
            return jsonify({'error': True, 'message': 'Invalid report type'}), 400

        # Save report to history
        report_id = report_history.save_report(data, report_type)

        return jsonify({
            'html_content': html_content,
            'report_id': report_id
        })

    except Exception as e:
        return jsonify({'error': True, 'message': f'Error: {str(e)}'}), 500


@app.route('/reports-history')
def view_reports_history():
    """View all saved reports"""
    return render_template('reports-history.html')


@app.route('/api/reports-history', methods=['GET'])
def get_reports_history():
    """Get all reports from history"""
    try:
        all_reports = report_history.get_all_reports()
        summary = report_history.export_reports_summary()

        return jsonify({
            'reports': all_reports,
            'summary': summary
        })

    except Exception as e:
        return jsonify({'error': True, 'message': f'Error: {str(e)}'}), 500


@app.route('/api/report/<report_id>', methods=['GET'])
def get_report_detail(report_id):
    """Get detailed report"""
    try:
        report = report_history.get_report(report_id)

        if not report:
            return jsonify({'error': True, 'message': 'Report not found'}), 404

        return jsonify(report)

    except Exception as e:
        return jsonify({'error': True, 'message': f'Error: {str(e)}'}), 500


@app.route('/api/report/<report_id>/delete', methods=['DELETE'])
def delete_report(report_id):
    """Delete a report"""
    try:
        success = report_history.delete_report(report_id)

        if not success:
            return jsonify({'error': True, 'message': 'Report not found'}), 404

        return jsonify({'success': True, 'message': 'Report deleted'})

    except Exception as e:
        return jsonify({'error': True, 'message': f'Error: {str(e)}'}), 500


@app.route('/api/report/<report_id>/download', methods=['GET'])
def download_report(report_id):
    """Download report as PDF"""
    try:
        import os
        report = report_history.get_report(report_id)

        if not report:
            return jsonify({'error': True, 'message': 'Report not found'}), 404

        # Generate PDF filename
        metadata = report.get('metadata', {})
        report_type = metadata.get('type', 'report')
        created_at = metadata.get('created_at', 'unknown')
        
        # Generate HTML content
        if report_type == 'comparison':
            html_content = PDFReportGenerator.generate_pdf_report(metadata)
        elif report_type == 'project':
            html_content = PDFReportGenerator.generate_project_pdf_report(metadata)
        else:
            return jsonify({'error': True, 'message': 'Unknown report type'}), 400

        # Try to convert to PDF
        try:
            from weasyprint import HTML
            import io
            
            pdf_file = io.BytesIO()
            HTML(string=html_content).write_pdf(pdf_file)
            pdf_file.seek(0)
            
            filename = f"report_{report_id[:8]}.pdf"
            return send_file(pdf_file, mimetype='application/pdf', as_attachment=True, download_name=filename)
        except ImportError:
            # If weasyprint not available, return HTML file
            return send_file(
                io.StringIO(html_content),
                mimetype='text/html',
                as_attachment=True,
                download_name=f"report_{report_id[:8]}.html"
            )

    except Exception as e:
        return jsonify({'error': True, 'message': f'Error: {str(e)}'}), 500


@app.route('/comparison-view')
def comparison_view():
    """Detailed comparison view page"""
    return render_template('comparison-view.html')


@app.route('/about')
def about():
    """About page"""
    return render_template('about.html')


@app.route('/help')
def help_page():
    """Help page"""
    return render_template('help.html')


@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return render_template('404.html'), 404


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    return render_template('500.html'), 500


if __name__ == '__main__':
    app.run(
        debug=True,
        host='0.0.0.0',
        port=5000,
        threaded=True
    )
