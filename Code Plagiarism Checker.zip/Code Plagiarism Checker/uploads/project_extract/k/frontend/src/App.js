import { useEffect, useState } from "react";

const translations = {
  en: { title: "AI Startup Builder", generate: "Generate Idea", health: "health", enter: "Enter domain (health, fintech...)", ideas: "Generated Ideas", no_ideas: "No ideas yet", view: "View Strategy Plan", hide: "Hide Strategy", validation: "Validation Score", pitch: "Pitch", fit: "Problem-Solution Fit", strategy: "Strategy", business: "Business", swot: "SWOT", mentor: "AI Mentor", send: "Send" },
  es: { title: "Constructor de Startups AI", generate: "Generar Idea", health: "salud", enter: "Ingresar dominio (salud, fintech...)", ideas: "Ideas Generadas", no_ideas: "Sin ideas todavía", view: "Ver Plan de Estrategia", hide: "Ocultar Estrategia", validation: "Puntaje de Validación", pitch: "Discurso", fit: "Ajuste Problema-Solución", strategy: "Estrategia", business: "Negocio", swot: "DAFO", market: "Mercado", mentor: "Mentor AI", send: "Enviar" },
  fr: { title: "Générateur de Startups IA", generate: "Générer Idée", health: "santé", enter: "Entrer domaine (santé, fintech...)", ideas: "Idées Générées", no_ideas: "Pas encore d'idées", view: "Voir la Stratégie", hide: "Masquer la Stratégie", validation: "Score de Validation", pitch: "Pitch", fit: "Adéquation Problème-Solution", strategy: "Stratégie", business: "Affaires", swot: "SWOT", market: "Marché", mentor: "Mentor IA", send: "Envoyer" }
};


function App() {
  const [ideas, setIdeas] = useState([]);
  const [wizardStep, setWizardStep] = useState(1);
  const [wizardAnswers, setWizardAnswers] = useState({ industry: "", problem: "", audience: "", tech: "AI" });
  const [lang, setLang] = useState("en");
  const [activeTabs, setActiveTabs] = useState({});
  const [chatOpen, setChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState([{ role: "ai", text: "Hello! I am your AI Startup Mentor. How can I help you today?" }]);
  const [newMsg, setNewMsg] = useState("");

  const t = translations[lang];

  useEffect(() => {
    fetch("http://localhost:5000/api/ideas")
      .then(res => res.json())
      .then(data => setIdeas(data))
      .catch(err => console.error("Error:", err));
  }, []);

  const handleWizardNext = () => setWizardStep(prev => prev + 1);
  const handleWizardPrev = () => setWizardStep(prev => prev - 1);

  const generateIdea = async () => {
    const res = await fetch("http://localhost:5000/api/ideas", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ needs: wizardAnswers })
    });
    const newIdea = await res.json();
    setIdeas([newIdea, ...ideas]);
    setWizardStep(1); // Reset wizard
    setWizardAnswers({ industry: "", problem: "", audience: "", tech: "AI" });
    window.scrollTo({ top: 600, behavior: 'smooth' });
  };

  const setTab = (ideaId, tab) => {
    setActiveTabs(prev => ({ ...prev, [ideaId]: tab }));
  };

  const sendMessage = async () => {
    if (!newMsg) return;
    const userMsg = { role: "user", text: newMsg };
    setChatMessages([...chatMessages, userMsg]);
    setNewMsg("");

    const res = await fetch("http://localhost:5000/api/mentor/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: newMsg })
    });
    const data = await res.json();
    setChatMessages(prev => [...prev, { role: "ai", text: data.response }]);
  };

  return (
    <div style={{ padding: "20px", fontFamily: "'Segoe UI', Roboto, sans-serif", backgroundColor: "#f0f2f5", minHeight: "100vh" }}>
      {/* Navbar */}
      <nav style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 40px", backgroundColor: "#fff", borderRadius: "12px", boxShadow: "0 2px 4px rgba(0,0,0,0.05)", marginBottom: "30px" }}>
        <h1 style={{ margin: 0, fontSize: "1.5rem" }}>🚀 {t.title}</h1>
        <div>
          {["en", "es", "fr"].map(l => (
            <button key={l} onClick={() => setLang(l)} style={{ marginLeft: "5px", padding: "5px 10px", borderRadius: "5px", border: lang === l ? "2px solid #007bff" : "1px solid #ccc", background: "white", cursor: "pointer", fontWeight: "bold" }}>
              {l.toUpperCase()}
            </button>
          ))}
        </div>
      </nav>

      {/* Discovery Wizard Section */}
      <div style={{ maxWidth: "700px", margin: "auto", backgroundColor: "#fff", padding: "40px", borderRadius: "20px", boxShadow: "0 20px 40px rgba(0,0,0,0.1)", marginBottom: "50px", textAlign: "center", position: "relative", overflow: "hidden" }}>

        {/* Progress Bar */}
        <div style={{ position: "absolute", top: 0, left: 0, height: "6px", width: `${(wizardStep / 4) * 100}%`, background: "linear-gradient(90deg, #007bff, #00d2ff)", transition: "width 0.4s ease" }} />

        {wizardStep === 1 && (
          <div className="fade-in">
            <h2 style={{ marginBottom: "20px" }}>🏢 {lang === 'en' ? 'Which industry excites you?' : '¿Qué industria te emociona?'}</h2>
            <input
              type="text"
              placeholder="e.g. Health, Fintech, Education..."
              value={wizardAnswers.industry}
              onChange={e => setWizardAnswers({ ...wizardAnswers, industry: e.target.value })}
              style={{ width: "100%", padding: "15px", borderRadius: "12px", border: "2px solid #eee", fontSize: "1.1rem", marginBottom: "20px" }}
            />
            <button disabled={!wizardAnswers.industry} onClick={handleWizardNext} style={{ padding: "15px 40px", borderRadius: "12px", border: "none", background: "#007bff", color: "white", fontSize: "1rem", cursor: "pointer", opacity: wizardAnswers.industry ? 1 : 0.5 }}>Next ➡️</button>
          </div>
        )}

        {wizardStep === 2 && (
          <div className="fade-in">
            <h2 style={{ marginBottom: "20px" }}>🛑 {lang === 'en' ? 'What is the biggest problem there?' : '¿Cuál es el mayor problema allí?'}</h2>
            <textarea
              rows="3"
              placeholder="e.g. High transaction fees, slow response times..."
              value={wizardAnswers.problem}
              onChange={e => setWizardAnswers({ ...wizardAnswers, problem: e.target.value })}
              style={{ width: "100%", padding: "15px", borderRadius: "12px", border: "2px solid #eee", fontSize: "1.1rem", marginBottom: "20px", fontFamily: "inherit" }}
            />
            <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
              <button onClick={handleWizardPrev} style={{ padding: "15px 20px", borderRadius: "12px", border: "1px solid #ccc", background: "#fff", cursor: "pointer" }}>⬅️ Back</button>
              <button disabled={!wizardAnswers.problem} onClick={handleWizardNext} style={{ padding: "15px 40px", borderRadius: "12px", border: "none", background: "#007bff", color: "white", cursor: "pointer", opacity: wizardAnswers.problem ? 1 : 0.5 }}>Next ➡️</button>
            </div>
          </div>
        )}

        {wizardStep === 3 && (
          <div className="fade-in">
            <h2 style={{ marginBottom: "20px" }}>👥 {lang === 'en' ? 'Who suffers most from this?' : '¿Quién sufre más por esto?'}</h2>
            <input
              type="text"
              placeholder="e.g. Small business owners, patients..."
              value={wizardAnswers.audience}
              onChange={e => setWizardAnswers({ ...wizardAnswers, audience: e.target.value })}
              style={{ width: "100%", padding: "15px", borderRadius: "12px", border: "2px solid #eee", fontSize: "1.1rem", marginBottom: "20px" }}
            />
            <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
              <button onClick={handleWizardPrev} style={{ padding: "15px 20px", borderRadius: "12px", border: "1px solid #ccc", background: "#fff", cursor: "pointer" }}>⬅️ Back</button>
              <button disabled={!wizardAnswers.audience} onClick={handleWizardNext} style={{ padding: "15px 40px", borderRadius: "12px", border: "none", background: "#007bff", color: "white", cursor: "pointer", opacity: wizardAnswers.audience ? 1 : 0.5 }}>Next ➡️</button>
            </div>
          </div>
        )}

        {wizardStep === 4 && (
          <div className="fade-in">
            <h2 style={{ marginBottom: "20px" }}>⚡ {lang === 'en' ? 'Key technology for the result?' : '¿Tecnología clave para el resultado?'}</h2>
            <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", justifyContent: "center", marginBottom: "30px" }}>
              {["AI", "Mobile App", "Blockchain", "SaaS", "Hardware"].map(t => (
                <button
                  key={t}
                  onClick={() => setWizardAnswers({ ...wizardAnswers, tech: t })}
                  style={{ padding: "12px 25px", borderRadius: "30px", border: wizardAnswers.tech === t ? "2px solid #007bff" : "1px solid #eee", background: wizardAnswers.tech === t ? "#eef2ff" : "#fff", color: wizardAnswers.tech === t ? "#007bff" : "#666", cursor: "pointer", fontWeight: "bold" }}
                >
                  {t}
                </button>
              ))}
            </div>
            <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
              <button onClick={handleWizardPrev} style={{ padding: "15px 20px", borderRadius: "12px", border: "1px solid #ccc", background: "#fff", cursor: "pointer" }}>⬅️ Back</button>
              <button onClick={generateIdea} style={{ padding: "15px 50px", borderRadius: "12px", border: "none", background: "linear-gradient(135deg, #007bff, #0056b3)", color: "white", fontSize: "1.1rem", fontWeight: "bold", cursor: "pointer" }}>✨ Generate Startup</button>
            </div>
          </div>
        )}
      </div>

      <div style={{ maxWidth: "900px", margin: "auto" }}>
        <h2 style={{ color: "#444" }}>{t.ideas}</h2>

        {ideas.length === 0 && <p style={{ textAlign: "center", color: "#666" }}>{t.no_ideas}</p>}

        {/* Ideas Dashboard */}
        <div style={{ display: "flex", flexDirection: "column", gap: "25px" }}>
          {ideas.map(idea => {
            const activeTab = activeTabs[idea.id] || "overview";
            return (
              <div key={idea.id} style={{ backgroundColor: "#fff", borderRadius: "16px", padding: "25px", boxShadow: "0 10px 25px rgba(0,0,0,0.05)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "20px" }}>
                  <div>
                    <h3 style={{ margin: "0 0 5px 0", fontSize: "1.4rem", color: "#007bff" }}>{idea.title}</h3>
                    <p style={{ color: "#666", margin: 0 }}>{idea.description}</p>
                  </div>
                  <div style={{ textAlign: "center" }}>
                    <div style={{ width: "60px", height: "60px", borderRadius: "50%", border: "4px solid #007bff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: "bold", color: "#007bff" }}>
                      {idea.validationScore}%
                    </div>
                    <span style={{ fontSize: "0.7rem", color: "#999" }}>{t.validation}</span>
                  </div>
                </div>

                {/* Tags View */}
                <div style={{ display: "flex", flexWrap: "wrap", gap: "10px", marginBottom: "20px" }}>
                  <span style={{ background: "#eef2ff", padding: "6px 12px", borderRadius: "20px", border: "1px solid #c7d2fe", color: "#4338ca", fontSize: "0.8rem" }}>💰 {idea.budget}</span>
                  <span style={{ background: "#ecfdf5", padding: "6px 12px", borderRadius: "20px", border: "1px solid #a7f3d0", color: "#065f46", fontSize: "0.8rem" }}>⏳ {idea.duration}</span>
                </div>

                {/* Tabs Navigation */}
                <div style={{ display: "flex", borderBottom: "1px solid #eee", marginBottom: "15px" }}>
                  {["overview", "strategy", "business", "swot", "market"].map(tab => (
                    <button
                      key={tab}
                      onClick={() => setTab(idea.id, tab)}
                      style={{ padding: "10px 20px", border: "none", background: "none", borderBottom: activeTab === tab ? "2px solid #007bff" : "none", color: activeTab === tab ? "#007bff" : "#666", cursor: "pointer", fontWeight: activeTab === tab ? "bold" : "normal" }}
                    >
                      {t[tab] || tab.charAt(0).toUpperCase() + tab.slice(1)}
                    </button>
                  ))}
                </div>

                {/* Tab Content */}
                <div style={{ minHeight: "150px" }}>
                  {activeTab === "overview" && (
                    <div>
                      <h4>📣 {t.pitch}</h4>
                      <p style={{ fontStyle: "italic", color: "#555" }}>"{idea.pitch}"</p>
                      <h4>🎯 {t.fit}</h4>
                      <p style={{ color: "#444" }}>{idea.problemSolutionFit}</p>
                    </div>
                  )}

                  {activeTab === "strategy" && (
                    <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                      {idea.strategy.map((item, idx) => (
                        <div key={idx} style={{ display: "flex", justifyContent: "space-between", padding: "10px", background: "#f8f9fa", borderRadius: "8px", borderLeft: "4px solid #007bff" }}>
                          <span>{item.task}</span>
                          <span style={{ fontSize: "0.8rem", color: "#007bff", fontWeight: "bold" }}>⏱️ {item.duration}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {activeTab === "business" && (
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
                      <div>
                        <h4>🏢 Business Model</h4>
                        <p>{idea.businessModel}</p>
                        <h4>👥 Target Audience</h4>
                        <p>{idea.targetAudience}</p>
                      </div>
                      <div>
                        <h4>🏆 Competitors</h4>
                        <ul>{idea.competitors.map(c => <li key={c}>{c}</li>)}</ul>
                        <h4>📈 Market Trends</h4>
                        <ul>{idea.marketTrends.map(tr => <li key={tr}>{tr}</li>)}</ul>
                      </div>
                    </div>
                  )}

                  {activeTab === "swot" && (
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
                      <div style={{ padding: "10px", background: "#dcfce7", borderRadius: "8px" }}>
                        <h5 style={{ margin: "0 0 5px 0", color: "#166534" }}>Strengths</h5>
                        <ul style={{ fontSize: "0.8rem", paddingLeft: "15px" }}>{idea.swot.strengths.map(s => <li key={s}>{s}</li>)}</ul>
                      </div>
                      <div style={{ padding: "10px", background: "#fee2e2", borderRadius: "8px" }}>
                        <h5 style={{ margin: "0 0 5px 0", color: "#991b1b" }}>Weaknesses</h5>
                        <ul style={{ fontSize: "0.8rem", paddingLeft: "15px" }}>{idea.swot.weaknesses.map(w => <li key={w}>{w}</li>)}</ul>
                      </div>
                      <div style={{ padding: "10px", background: "#fef9c3", borderRadius: "8px" }}>
                        <h5 style={{ margin: "0 0 5px 0", color: "#854d0e" }}>Opportunities</h5>
                        <ul style={{ fontSize: "0.8rem", paddingLeft: "15px" }}>{idea.swot.opportunities.map(o => <li key={o}>{o}</li>)}</ul>
                      </div>
                      <div style={{ padding: "10px", background: "#dbeafe", borderRadius: "8px" }}>
                        <h5 style={{ margin: "0 0 5px 0", color: "#1e40af" }}>Threats</h5>
                        <ul style={{ fontSize: "0.8rem", paddingLeft: "15px" }}>{idea.swot.threats.map(th => <li key={th}>{th}</li>)}</ul>
                      </div>
                    </div>
                  )}

                  {activeTab === "market" && (
                    <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
                      <div style={{ padding: "15px", background: "#f0f9ff", borderRadius: "12px", borderLeft: "5px solid #0ea5e9" }}>
                        <h4 style={{ margin: "0 0 10px 0", color: "#0369a1", display: "flex", alignItems: "center", gap: "8px" }}>
                          📍 Market Gap (Where it's missing)
                        </h4>
                        <p style={{ color: "#0c4a6e", margin: 0 }}>{idea.marketGap}</p>
                      </div>
                      <div style={{ padding: "15px", background: "#f0fdf4", borderRadius: "12px", borderLeft: "5px solid #22c55e" }}>
                        <h4 style={{ margin: "0 0 10px 0", color: "#166534", display: "flex", alignItems: "center", gap: "8px" }}>
                          🏗️ Regional Implementation Strategy
                        </h4>
                        <div style={{ color: "#14532d" }}>
                          {idea.regionalImplementation.split('. ').map((step, idx) => (
                            <p key={idx} style={{ margin: "5px 0" }}>{step.includes('.') ? step : step + '.'}</p>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* AI Mentor Chat Widget */}
      <div style={{ position: "fixed", bottom: "30px", right: "30px", zIndex: 1000 }}>
        {!chatOpen ? (
          <button onClick={() => setChatOpen(true)} style={{ width: "60px", height: "60px", borderRadius: "50%", background: "#007bff", color: "white", border: "none", cursor: "pointer", fontSize: "1.5rem", boxShadow: "0 4px 12px rgba(0,0,0,0.2)" }}>
            💬
          </button>
        ) : (
          <div style={{ width: "300px", height: "400px", background: "white", borderRadius: "12px", boxShadow: "0 10px 40px rgba(0,0,0,0.2)", display: "flex", flexDirection: "column" }}>
            <div style={{ padding: "15px", background: "#007bff", color: "white", borderRadius: "12px 12px 0 0", display: "flex", justifyContent: "space-between" }}>
              <strong>{t.mentor}</strong>
              <button onClick={() => setChatOpen(false)} style={{ background: "none", border: "none", color: "white", cursor: "pointer" }}>✕</button>
            </div>
            <div style={{ flex: 1, padding: "15px", overflowY: "auto", display: "flex", flexDirection: "column", gap: "10px" }}>
              {chatMessages.map((m, i) => (
                <div key={i} style={{ alignSelf: m.role === "user" ? "flex-end" : "flex-start", padding: "8px 12px", borderRadius: "12px", background: m.role === "user" ? "#007bff" : "#f1f1f1", color: m.role === "user" ? "white" : "#333", fontSize: "0.9rem", maxWidth: "80%)" }}>
                  {m.text}
                </div>
              ))}
            </div>
            <div style={{ padding: "10px", display: "flex", gap: "5px" }}>
              <input value={newMsg} onChange={e => setNewMsg(e.target.value)} onKeyPress={e => e.key === "Enter" && sendMessage()} placeholder="Ask anything..." style={{ flex: 1, padding: "8px", borderRadius: "5px", border: "1px solid #ddd" }} />
              <button onClick={sendMessage} style={{ background: "#007bff", color: "white", border: "none", padding: "8px 12px", borderRadius: "5px", cursor: "pointer" }}>{t.send}</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;


