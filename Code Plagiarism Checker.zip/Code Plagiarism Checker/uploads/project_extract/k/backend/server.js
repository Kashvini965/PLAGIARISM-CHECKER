const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const ideas = [
  {
    id: 1,
    title: "HealthTech AI",
    description: "AI-driven diagnostic tool for early detection of chronic diseases.",
    budget: "$10k - $25k",
    duration: "6 months",
    targetAudience: "Primary care physicians and hospitals",
    revenueModel: "SaaS subscription per clinic/doctor",
    validationScore: 85,
    problemSolutionFit: "High. Addresses the critical shortage of specialists by providing AI-assisted preliminary diagnostics.",
    pitch: "We help doctors save lives by catching chronic diseases 2 years earlier using AI. It's a SaaS diagnostic layer that fits into any existing clinic workflow.",
    businessModel: "B2B SaaS. We charge clinics a monthly subscription plus a per-scan fee.",
    competitors: ["Theranos (Pivot)", "Viz.ai", "Butterfly Network"],
    marketGap: "Rural Southeast Asia and parts of Sub-Saharan Africa where specialist density is less than 1 per 100,000 residents.",
    regionalImplementation: "1. Partner with local NGOs for data relay. 2. Deploy via mobile-first satellite internet. 3. Train community health workers on basic device operation.",
    swot: {
      strengths: ["Highly accurate models", "Low hardware costs", "Expert medical board"],
      weaknesses: ["Regulatory hurdles", "Data privacy concerns"],
      opportunities: ["Global expansion to underserved regions", "Home-use version"],
      threats: ["Changes in healthcare laws", "Competition from big tech (Google Health)"]
    },
    marketTrends: ["Rise of telehealth", "AI in medical imaging", "Personalized medicine preference"],
    strategy: [
      { task: "Gather clinical data partnerships", duration: "1 month" },
      { task: "Develop and train AI diagnostic models", duration: "2 months" },
      { task: "Obtain regulatory certifications (FDA/CE)", duration: "2 months" },
      { task: "Pilot launch in select medical clinics", duration: "1 month" }
    ]
  }
];



app.get("/api/test", (req, res) => {
  res.json({ message: "Backend connected successfully 🚀" });
});

// GET all ideas
app.get("/api/ideas", (req, res) => {
  res.json(ideas);
});

// POST new idea
app.post("/api/ideas", (req, res) => {
  const { needs } = req.body;
  const { industry, problem, audience, tech } = needs || { industry: "unknown", problem: "efficiency", audience: "businesses", tech: "AI" };

  const title = `${industry.charAt(0).toUpperCase() + industry.slice(1)} ${tech} Explorer`;
  const description = `A powerful platform designed specifically for ${audience} to solve the ${problem} issue in the ${industry} sector using ${tech}.`;

  const newIdea = {
    id: ideas.length + 1,
    title: title,
    description: description,
    budget: `$${Math.floor(Math.random() * 10) + 5}k - $${Math.floor(Math.random() * 20) + 20}k`,
    duration: `${Math.floor(Math.random() * 6) + 3} months`,
    targetAudience: audience,
    revenueModel: "SaaS and transaction-based pricing",
    validationScore: Math.floor(Math.random() * 30) + 60,
    problemSolutionFit: `Users reported that ${problem} is their #1 pain point. This ${tech} solution automates the resolution, saving them hours weekly.`,
    pitch: `We help ${audience} eliminate ${problem} in ${industry}. It's the only ${tech}-first solution built for this specific need.`,
    businessModel: "B2B SaaS. We offer a 30-day free trial followed by a tiered subscription.",
    competitors: [`Legacy ${industry} Tools`, "Manual workflows", "Generic consultants"],
    marketGap: `Emerging markets in Asia and Latin America where existing ${industry} solutions are either too expensive or lack ${tech} native features.`,
    regionalImplementation: `1. Localize the ${tech} interface for regional languages. 2. Hire 5 local field sales reps for direct ${audience} outreach. 3. Offer a entry-level pricing tier for small ${industry} players in that region.`,
    swot: {
      strengths: [`Deep focus on ${industry}`, `Advanced ${tech} integration`, "User-centric design"],
      weaknesses: ["New brand entry", "Requires initial data training"],
      opportunities: [`Scaling to all ${audience} worldwide`, "AI-driven predictive analytics"],
      threats: ["Low barrier to entry for generic players", "Sensitive industry regulations"]
    },
    marketTrends: [`Rising demand for ${tech} in ${industry}`, `Need for personalization for ${audience}`, "Low-code automation trends"],
    strategy: [
      { task: `Validate ${problem} with 50 potential ${audience}`, duration: "2 weeks" },
      { task: `Develop MVP focusing on core ${tech} functionality`, duration: "2 months" },
      { task: `Launch beta with select ${industry} partners`, duration: "1 month" },
      { task: "Full release and customer acquisition scale-up", duration: "4 months" }
    ]
  };
  ideas.push(newIdea);
  res.json(newIdea);
});


// AI Mentor Chatbot Endpoint
app.post("/api/mentor/chat", (req, res) => {
  const { message } = req.body;
  const responses = [
    "That sounds like a solid startup idea! Have you considered your first 10 customers?",
    "Focus on your Minimum Viable Product (MVP) first. Don't over-engineer.",
    "The biggest risk for your idea is market timing. Is the market ready for this now?",
    "Great question. Most startups fail due to lack of market need, not technical failure.",
    "Your strategy looks good, but I would suggest shortening the prototype phase."
  ];
  const response = responses[Math.floor(Math.random() * responses.length)];
  res.json({ response });
});



app.listen(5000, () => {
  console.log("Backend running on http://localhost:5000");
});

