# Code Plagiarism Checker

A comprehensive web-based tool for detecting code plagiarism using advanced similarity algorithms.

## 🎯 Overview

Code Plagiarism Checker is a sophisticated application designed to detect and analyze code similarities between different source files. It uses multiple advanced algorithms to identify potential plagiarism with high accuracy and provides detailed analysis reports.

## ✨ Features

- **Multiple Comparison Algorithms**
  - Sequence Matching (longest contiguous matching subsequences)
  - Jaccard Similarity (set-based similarity)
  - Cosine Similarity (token frequency distribution)

- **Multi-Language Support**
  - Supports 20+ programming languages
  - Python, Java, C++, C, JavaScript, TypeScript, HTML, CSS, PHP, Ruby, Go, Rust, Swift, Kotlin, Scala, C#, VB.NET, R, Lua, Shell, and more

- **Flexible Input Methods**
  - Upload code files (up to 10MB)
  - Paste code snippets directly
  - Compare across different file formats

- **Comprehensive Analysis**
  - Detailed similarity metrics
  - Suspicious portions identification
  - Color-coded risk assessment
  - Contextual recommendations

- **Multiple Report Formats**
  - HTML reports with styling
  - Plain text reports
  - JSON for programmatic use

- **User-Friendly Interface**
  - Clean, intuitive web interface
  - Real-time analysis
  - Responsive design for all devices

## 🚀 Quick Start

### Prerequisites
- Python 3.7 or higher
- pip (Python package manager)

### Installation

1. **Clone or download the project**
   ```bash
   cd "Code Plagiarism Checker"
   ```

2. **Create a Python virtual environment** (recommended)
   ```bash
   python -m venv venv
   
   # On Windows
   venv\Scripts\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

### Running the Application

1. **Start the Flask server**
   ```bash
   python app.py
   ```

2. **Open your browser**
   - Navigate to `http://localhost:5000`
   - You should see the Code Plagiarism Checker interface

## 📋 Usage

### Method 1: Upload Files
1. Go to the "Upload Files" tab
2. Select two code files to compare
3. Click "Compare Files"
4. Review the analysis results
5. Download reports in your preferred format

### Method 2: Compare Code Snippets
1. Go to the "Compare Code" tab
2. Paste your first code snippet
3. Paste your second code snippet
4. Click "Compare Code"
5. Review the results and download reports

## 📊 Understanding Results

### Similarity Percentage Interpretation
- **90-100%**: Very high similarity - almost certainly plagiarized
- **75-89%**: High similarity - likely plagiarized
- **60-74%**: Moderate similarity - may be plagiarized
- **40-59%**: Low similarity - possibly coincidental
- **0-39%**: Very low similarity - likely original work

### Metrics Explained
- **Sequence Matching**: Detects direct code copying and similar sequences
- **Jaccard Similarity**: Identifies structural similarities even when code is reorganized
- **Cosine Similarity**: Compares code token frequency patterns

## 🏗️ Project Structure

```
Code Plagiarism Checker/
├── app.py                      # Main Flask application
├── config.py                   # Configuration settings
├── requirements.txt            # Python dependencies
├── README.md                   # This file
├── .gitignore                  # Git ignore rules
├── src/                        # Source modules
│   ├── __init__.py
│   ├── plagiarism_detector.py  # Core detection algorithms
│   ├── file_parser.py          # File handling
│   ├── similarity_calculator.py # Similarity calculations
│   └── report_generator.py     # Report generation
├── templates/                  # HTML templates
│   ├── base.html              # Base template
│   ├── index.html             # Home page
│   ├── about.html             # About page
│   ├── help.html              # Help/documentation
│   ├── 404.html               # 404 error page
│   └── 500.html               # 500 error page
├── static/                     # Static files
│   ├── css/
│   │   └── style.css          # Stylesheet
│   └── js/
│       └── script.js          # JavaScript utilities
└── uploads/                    # Temporary file uploads (auto-cleaned)
```

## 🔧 Configuration

Edit `config.py` to customize:
- **PLAGIARISM_THRESHOLD**: Minimum similarity percentage for flagging plagiarism (default: 70%)
- **MAX_CONTENT_LENGTH**: Maximum file upload size (default: 10MB)
- **ALLOWED_EXTENSIONS**: Supported file extensions
- **DEBUG**: Enable/disable debug mode

## 🛠️ Development

### Adding Support for New Languages

1. Add the file extension to `SUPPORTED_EXTENSIONS` in `src/file_parser.py`
2. Add language mapping to `language_map` in the same file
3. Update `requirements.txt` if specialized parsers are needed

### Customizing Algorithms

Edit `src/plagiarism_detector.py` to:
- Adjust tokenization rules
- Modify similarity thresholds
- Add new similarity algorithms
- Change code normalization methods

## 📝 API Endpoints

- `POST /api/upload` - Compare uploaded files
- `POST /api/compare-text` - Compare code snippets
- `POST /api/report/<format>` - Generate reports (html, text, json)

## ⚠️ Limitations

- **Maxium file size**: 10MB per file
- **Plain text only**: Binary files not supported
- **Automated limitations**: Cannot detect highly obfuscated code
- **Context matters**: Results should be reviewed in context of surrounding evidence

## 🔒 Privacy & Security

- Files are analyzed locally during comparison
- Uploaded files are temporarily stored during processing
- All temporary files are automatically deleted after analysis
- No files are permanently stored on the server
- For production deployment, consider using HTTPS and adding authentication

## 📚 Supported Programming Languages

Python, Java, C/C++, JavaScript, TypeScript, HTML, CSS, PHP, Ruby, Go, Rust, Swift, Kotlin, Scala, C#, VB.NET, R, Objective-C, Lua, Perl, Shell Script, and more...

## 🤝 Contributing

Contributions are welcome! To improve the tool:
1. Report bugs and issues
2. Suggest enhancements
3. Submit pull requests
4. Improve documentation

## 📄 License

This project is open source and available under the MIT License.

## 🎓 Disclaimer

This tool is designed to assist in detecting potential plagiarism. Results should be reviewed by qualified professionals. No automated system is perfect, and this tool should be used as one of several tools in a comprehensive plagiarism detection strategy. Always verify results with human review.

## 🆘 Troubleshooting

### Port Already in Use
If port 5000 is already in use, edit `app.py` and change the port number:
```python
if __name__ == '__main__':
    app.run(port=5001)  # or any other available port
```

### File Upload Issues
- Ensure file size is under 10MB
- Use supported file formats only
- Check file encoding (UTF-8 recommended)

### Performance Issues
- Consider optimizing code normalization for very large files
- Adjust `PLAGIARISM_THRESHOLD` for faster results

## 📞 Support

For issues, questions, or feature requests, please open an issue or contact the development team.

---

**Made with ❤️ for academic integrity**

Last Updated: March 2024
