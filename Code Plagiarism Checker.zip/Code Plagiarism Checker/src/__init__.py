"""Code Plagiarism Checker - Core Module"""

__version__ = "1.0.0"
__author__ = "Plagiarism Checker Team"
