"""
File parsing module for handling various code file formats
"""

import os
from typing import Tuple, Optional


class FileParser:
    """Parser for handling different code file types"""

    # Supported file extensions
    SUPPORTED_EXTENSIONS = {
        '.py', '.java', '.cpp', '.c', '.js', '.ts', '.html', '.css',
        '.php', '.rb', '.go', '.rs', '.swift', '.kotlin', '.scala',
        '.cs', '.vb', '.r', '.m', '.swift', '.lua', '.pl', '.sh'
    }

    @staticmethod
    def is_supported(filename: str) -> bool:
        """Check if file type is supported"""
        _, ext = os.path.splitext(filename.lower())
        return ext in FileParser.SUPPORTED_EXTENSIONS

    @staticmethod
    def read_file(filepath: str) -> Optional[str]:
        """
        Read and return file content
        Handles text files safely
        """
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as file:
                content = file.read()
            return content
        except Exception as e:
            raise Exception(f"Error reading file {filepath}: {str(e)}")

    @staticmethod
    def get_file_info(filepath: str) -> Tuple[str, str, int]:
        """
        Extract file information
        Returns: (filename, extension, file_size_kb)
        """
        filename = os.path.basename(filepath)
        _, extension = os.path.splitext(filename)
        file_size_kb = os.path.getsize(filepath) / 1024

        return filename, extension, round(file_size_kb, 2)

    @staticmethod
    def validate_file(filepath: str, max_size_mb: int = 10) -> Tuple[bool, str]:
        """
        Validate if file meets requirements
        Returns: (is_valid, message)
        """
        # Check if file exists
        if not os.path.exists(filepath):
            return False, "File does not exist"

        # Check file type
        if not FileParser.is_supported(filepath):
            return False, f"File type not supported. Supported types: {', '.join(FileParser.SUPPORTED_EXTENSIONS)}"

        # Check file size
        file_size_mb = os.path.getsize(filepath) / (1024 * 1024)
        if file_size_mb > max_size_mb:
            return False, f"File size exceeds {max_size_mb}MB limit"

        return True, "File is valid"

    @staticmethod
    def get_language(filepath: str) -> Optional[str]:
        """Detect programming language from file extension"""
        language_map = {
            '.py': 'Python',
            '.java': 'Java',
            '.cpp': 'C++',
            '.c': 'C',
            '.js': 'JavaScript',
            '.ts': 'TypeScript',
            '.html': 'HTML',
            '.css': 'CSS',
            '.php': 'PHP',
            '.rb': 'Ruby',
            '.go': 'Go',
            '.rs': 'Rust',
            '.swift': 'Swift',
            '.kotlin': 'Kotlin',
            '.scala': 'Scala',
            '.cs': 'C#',
            '.vb': 'VB.NET',
            '.r': 'R',
            '.m': 'Objective-C',
            '.lua': 'Lua',
            '.pl': 'Perl',
            '.sh': 'Shell'
        }
        _, ext = os.path.splitext(filepath.lower())
        return language_map.get(ext, 'Unknown')
