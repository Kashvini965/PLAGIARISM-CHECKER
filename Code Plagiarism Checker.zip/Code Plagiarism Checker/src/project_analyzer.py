"""
Project analyzer module for batch plagiarism detection
Handles scanning multiple files in a project directory
"""

import os
import zipfile
from typing import Dict, List, Tuple, Optional
from src.file_parser import FileParser
from src.similarity_calculator import SimilarityCalculator
from src.plagiarism_detector import PlagiarismDetector


class ProjectAnalyzer:
    """Analyze entire projects for plagiarism detection"""

    def __init__(self):
        self.detector = PlagiarismDetector()
        self.calculator = SimilarityCalculator()
        self.ignored_dirs = {'.git', '__pycache__', 'node_modules', '.env', 'venv', '.vscode', 'dist', 'build'}
        self.ignored_files = {'.gitignore', '.env', '.DS_Store', 'thumbs.db'}

    def extract_and_analyze_zip(self, zip_path: str, upload_folder: str) -> Tuple[str, List[Dict]]:
        """
        Extract project zip and analyze all files
        Returns: (project_name, analysis_results)
        """
        try:
            # Extract zip to temporary directory
            extract_path = os.path.join(upload_folder, 'project_extract')
            os.makedirs(extract_path, exist_ok=True)

            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_path)

            # Get project name from zip filename
            project_name = os.path.splitext(os.path.basename(zip_path))[0]

            # Analyze extracted project
            all_files = self._collect_project_files(extract_path)
            analysis_results = self._analyze_files(all_files)

            return project_name, analysis_results

        except Exception as e:
            raise Exception(f"Error processing project: {str(e)}")

    def analyze_project_folder(self, folder_path: str) -> Tuple[str, List[Dict]]:
        """
        Analyze a project folder directly
        Returns: (project_name, analysis_results)
        """
        try:
            if not os.path.exists(folder_path):
                raise Exception("Project folder not found")

            project_name = os.path.basename(folder_path)
            all_files = self._collect_project_files(folder_path)
            analysis_results = self._analyze_files(all_files)

            return project_name, analysis_results

        except Exception as e:
            raise Exception(f"Error analyzing project: {str(e)}")

    def _collect_project_files(self, root_path: str) -> List[Tuple[str, str]]:
        """
        Collect all supported code files from project
        Returns: List of (file_path, relative_path) tuples
        """
        code_files = []

        for root, dirs, files in os.walk(root_path):
            # Remove ignored directories
            dirs[:] = [d for d in dirs if d not in self.ignored_dirs]

            for file in files:
                if file not in self.ignored_files and FileParser.is_supported(file):
                    full_path = os.path.join(root, file)
                    relative_path = os.path.relpath(full_path, root_path)
                    code_files.append((full_path, relative_path))

        return code_files

    def _analyze_files(self, code_files: List[Tuple[str, str]]) -> List[Dict]:
        """
        Analyze collected files for plagiarism
        Performs pairwise comparison
        """
        results = []

        if len(code_files) < 2:
            return [{
                'error': True,
                'message': 'Project must contain at least 2 code files for plagiarism comparison'
            }]

        # Perform pairwise analysis
        for i, (file1_path, file1_rel) in enumerate(code_files):
            for j in range(i + 1, len(code_files)):
                file2_path, file2_rel = code_files[j]

                # Skip if languages are too different
                ext1 = os.path.splitext(file1_rel)[1]
                ext2 = os.path.splitext(file2_rel)[1]

                # Allow comparison between similar language families
                if not self._are_compatible_languages(ext1, ext2):
                    continue

                try:
                    # Compare files
                    comparison = self.calculator.compare_files(file1_path, file2_path)

                    if not comparison.get('error'):
                        similarity = comparison['analysis']['average_similarity']

                        # Only include significant matches
                        if similarity >= 30:  # 30% threshold for project reports
                            results.append({
                                'file1': file1_rel,
                                'file2': file2_rel,
                                'similarity': similarity,
                                'is_plagiarized': comparison['analysis'].get('is_plagiarized', False),
                                'sequence_similarity': comparison['analysis'].get('sequence_similarity', 0),
                                'jaccard_similarity': comparison['analysis'].get('jaccard_similarity', 0),
                                'cosine_similarity': comparison['analysis'].get('cosine_similarity', 0),
                                'total_matches': comparison['analysis'].get('total_matches', 0),
                                'recommendation': comparison.get('recommendation', '')
                            })
                except Exception as e:
                    # Log error but continue analysis
                    results.append({
                        'file1': file1_rel,
                        'file2': file2_rel,
                        'error': True,
                        'message': str(e)
                    })

        # Sort by similarity (highest first)
        results.sort(key=lambda x: x.get('similarity', 0), reverse=True)

        return results

    @staticmethod
    def _are_compatible_languages(ext1: str, ext2: str) -> bool:
        """Check if two file extensions are compatible for comparison"""
        # Language families
        web_langs = {'.js', '.ts', '.jsx', '.tsx', '.html', '.css', '.php', '.vue'}
        python_langs = {'.py', '.pyw'}
        c_langs = {'.c', '.cpp', '.cc', '.cxx', '.h', '.hpp'}
        java_langs = {'.java', '.scala', '.kotlin'}
        other_langs = {'.rb', '.go', '.rs', '.swift', '.m', '.cs', '.vb', '.lua', '.pl', '.sh'}

        families = [web_langs, python_langs, c_langs, java_langs, other_langs]

        for family in families:
            if ext1.lower() in family and ext2.lower() in family:
                return True

        return False

    def calculate_project_statistics(self, results: List[Dict]) -> Dict:
        """Calculate overall project statistics"""
        if not results:
            return {
                'total_comparisons': 0,
                'files_with_plagiarism': 0,
                'average_similarity': 0,
                'highest_similarity': 0,
                'files_error': 0
            }

        valid_results = [r for r in results if not r.get('error')]

        if not valid_results:
            return {
                'total_comparisons': len(results),
                'files_with_plagiarism': 0,
                'average_similarity': 0,
                'highest_similarity': 0,
                'files_error': len(results)
            }

        plagiarism_count = sum(1 for r in valid_results if r.get('is_plagiarized'))
        similarities = [r['similarity'] for r in valid_results]

        return {
            'total_comparisons': len(valid_results),
            'files_with_plagiarism': plagiarism_count,
            'average_similarity': round(sum(similarities) / len(similarities), 2),
            'highest_similarity': round(max(similarities), 2),
            'files_error': len([r for r in results if r.get('error')])
        }
