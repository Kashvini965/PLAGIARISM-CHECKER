"""
Detailed plagiarism detection module
Identifies specific segments and exact locations of plagiarism
"""

import re
from typing import Dict, List, Tuple
from difflib import SequenceMatcher


class DetailedDetector:
    """Detailed plagiarism detection with segment identification"""

    def __init__(self):
        self.min_match_length = 2  # Minimum tokens for match

    def detect_plagiarized_segments(self, code1: str, code2: str) -> Dict:
        """
        Detect all plagiarized segments with exact locations
        """
        # Tokenize both codes
        tokens1 = self._tokenize(code1)
        tokens2 = self._tokenize(code2)

        # Find all matching segments
        segments = self._find_all_segments(tokens1, tokens2, code1, code2)

        # Calculate statistics
        total_matching_tokens = sum(s['token_length'] for s in segments)
        total_tokens1 = len(tokens1)
        total_tokens2 = len(tokens2)

        plagiarism_score = self._calculate_plagiarism_score(
            total_matching_tokens, total_tokens1, total_tokens2
        )

        return {
            'segments': segments,
            'total_matching_tokens': total_matching_tokens,
            'total_tokens_file1': total_tokens1,
            'total_tokens_file2': total_tokens2,
            'plagiarism_score': plagiarism_score,
            'segment_count': len(segments),
            'average_segment_length': (
                sum(s['token_length'] for s in segments) / len(segments) 
                if segments else 0
            )
        }

    def _tokenize(self, code: str) -> List[str]:
        """Tokenize code into meaningful units"""
        # Remove comments
        code = re.sub(r'//.*', '', code)
        code = re.sub(r'/\*.*?\*/', '', code, flags=re.DOTALL)
        code = re.sub(r'#.*', '', code)

        # Tokenize
        tokens = re.findall(r'\b\w+\b|[(){}\[\];,.]', code)
        return tokens

    def _find_all_segments(self, tokens1: List[str], tokens2: List[str], 
                          code1: str, code2: str) -> List[Dict]:
        """Find all matching segments"""
        segments = []
        matcher = SequenceMatcher(None, tokens1, tokens2)

        for block in matcher.get_matching_blocks():
            if block.size >= self.min_match_length:
                segment = {
                    'file1_start_token': block.a,
                    'file1_end_token': block.a + block.size,
                    'file2_start_token': block.b,
                    'file2_end_token': block.b + block.size,
                    'token_length': block.size,
                    'matched_tokens': tokens1[block.a:block.a + block.size],
                    'matched_code': ' '.join(tokens1[block.a:block.a + block.size]),
                    'file1_line_start': self._token_pos_to_line(tokens1[:block.a], code1),
                    'file1_line_end': self._token_pos_to_line(tokens1[:block.a + block.size], code1),
                    'file2_line_start': self._token_pos_to_line(tokens2[:block.b], code2),
                    'file2_line_end': self._token_pos_to_line(tokens2[:block.b + block.size], code2),
                    'confidence': 100  # Exact token match
                }
                segments.append(segment)

        # Sort by token length (longest first)
        return sorted(segments, key=lambda x: x['token_length'], reverse=True)

    def _token_pos_to_line(self, tokens: List[str], code: str) -> int:
        """Convert token position to line number"""
        reconstructed = ' '.join(tokens)
        line_count = code[:len(reconstructed)].count('\n') + 1
        return line_count

    def _calculate_plagiarism_score(self, matching_tokens: int, 
                                   total1: int, total2: int) -> float:
        """Calculate overall plagiarism score"""
        if total1 == 0 or total2 == 0:
            return 0.0

        avg_total = (total1 + total2) / 2
        score = (matching_tokens / avg_total) * 100

        return round(min(score, 100), 2)

    def generate_segment_report(self, segment_data: Dict) -> Dict:
        """Generate detailed report for segments"""
        segments = segment_data.get('segments', [])

        report = {
            'total_segments': len(segments),
            'high_confidence_segments': len([s for s in segments if s['confidence'] >= 80]),
            'medium_confidence_segments': len([s for s in segments if 50 <= s['confidence'] < 80]),
            'segments_by_size': self._segment_by_size(segments),
            'top_segments': segments[:5] if segments else []
        }

        return report

    @staticmethod
    def _segment_by_size(segments: List[Dict]) -> Dict:
        """Group segments by token length"""
        grouped = {
            'large': len([s for s in segments if s['token_length'] > 20]),
            'medium': len([s for s in segments if 10 <= s['token_length'] <= 20]),
            'small': len([s for s in segments if s['token_length'] < 10])
        }
        return grouped

    def highlight_segments(self, code: str, segments: List[Dict]) -> str:
        """
        Highlight plagiarized segments in code
        Returns HTML with highlighted sections
        """
        lines = code.split('\n')
        highlighted_lines = []

        # Create a set of highlighted line ranges
        highlighted_ranges = set()
        for segment in segments:
            for line_num in range(segment['file1_line_start'] - 1, segment['file1_line_end']):
                highlighted_ranges.add(line_num)

        html = '<pre style="background: #f5f5f5; padding: 15px; border-radius: 4px; overflow-x: auto;">'

        for i, line in enumerate(lines):
            if i in highlighted_ranges:
                html += f'<span style="background-color: #ffeb3b; display: block; padding: 2px 5px;">'
                html += f'<strong>[{i+1}]</strong> {self._escape_html(line)}\n'
                html += '</span>'
            else:
                html += f'<span style="display: block; padding: 2px 5px;"><strong>[{i+1}]</strong> {self._escape_html(line)}\n</span>'

        html += '</pre>'
        return html

    @staticmethod
    def _escape_html(text: str) -> str:
        """Escape HTML special characters"""
        return (text.replace('&', '&amp;')
                    .replace('<', '&lt;')
                    .replace('>', '&gt;')
                    .replace('"', '&quot;')
                    .replace("'", '&#39;'))
