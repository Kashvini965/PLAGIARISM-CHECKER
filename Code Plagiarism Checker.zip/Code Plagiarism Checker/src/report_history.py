"""
Report history and storage module
Manages saving and retrieving plagiarism detection reports
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Optional
import hashlib


class ReportHistory:
    """Manage report history and storage"""

    def __init__(self, history_folder: str = "reports_history"):
        self.history_folder = history_folder
        os.makedirs(history_folder, exist_ok=True)

    def save_report(self, report_data: Dict, report_type: str = "comparison") -> str:
        """
        Save a report to history
        Returns report ID
        """
        report_id = self._generate_report_id(report_data)
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # Create report metadata
        metadata = {
            'id': report_id,
            'type': report_type,
            'timestamp': timestamp,
            'created_at': datetime.now().isoformat(),
            'file1': report_data.get('file1', {}).get('name', 'Unknown'),
            'file2': report_data.get('file2', {}).get('name', 'Unknown'),
            'project_name': report_data.get('project_name', None),
            'similarity': report_data.get('analysis', {}).get('average_similarity', 0) if report_type == 'comparison' 
                          else report_data.get('statistics', {}).get('average_similarity', 0),
            'is_plagiarized': report_data.get('analysis', {}).get('is_plagiarized', False) if report_type == 'comparison'
                             else report_data.get('statistics', {}).get('files_with_plagiarism', 0) > 0
        }

        # Save full report
        report_path = os.path.join(self.history_folder, f"{report_id}.json")
        with open(report_path, 'w') as f:
            json.dump({
                'metadata': metadata,
                'data': report_data
            }, f, indent=2)

        return report_id

    def get_report(self, report_id: str) -> Optional[Dict]:
        """Retrieve a report by ID"""
        report_path = os.path.join(self.history_folder, f"{report_id}.json")

        if not os.path.exists(report_path):
            return None

        with open(report_path, 'r') as f:
            return json.load(f)

    def get_all_reports(self) -> List[Dict]:
        """Get all saved reports with metadata"""
        reports = []

        for filename in os.listdir(self.history_folder):
            if filename.endswith('.json'):
                report_path = os.path.join(self.history_folder, filename)
                with open(report_path, 'r') as f:
                    data = json.load(f)
                    reports.append(data['metadata'])

        # Sort by timestamp (newest first)
        return sorted(reports, key=lambda x: x['created_at'], reverse=True)

    def get_reports_by_type(self, report_type: str) -> List[Dict]:
        """Get reports filtered by type"""
        all_reports = self.get_all_reports()
        return [r for r in all_reports if r['type'] == report_type]

    def get_high_risk_reports(self, threshold: float = 75) -> List[Dict]:
        """Get reports with plagiarism above threshold"""
        all_reports = self.get_all_reports()
        return [r for r in all_reports if r['similarity'] >= threshold]

    def delete_report(self, report_id: str) -> bool:
        """Delete a report"""
        report_path = os.path.join(self.history_folder, f"{report_id}.json")

        if os.path.exists(report_path):
            os.remove(report_path)
            return True

        return False

    def export_reports_summary(self) -> Dict:
        """Export summary statistics of all reports"""
        all_reports = self.get_all_reports()

        if not all_reports:
            return {
                'total_reports': 0,
                'comparison_reports': 0,
                'project_reports': 0,
                'average_similarity': 0,
                'high_risk_count': 0
            }

        comparison_reports = [r for r in all_reports if r['type'] == 'comparison']
        project_reports = [r for r in all_reports if r['type'] == 'project']
        high_risk = [r for r in all_reports if r['similarity'] >= 75]

        similarities = [r['similarity'] for r in all_reports if r['similarity'] is not None]
        avg_similarity = sum(similarities) / len(similarities) if similarities else 0

        return {
            'total_reports': len(all_reports),
            'comparison_reports': len(comparison_reports),
            'project_reports': len(project_reports),
            'average_similarity': round(avg_similarity, 2),
            'high_risk_count': len(high_risk),
            'latest_report': all_reports[0] if all_reports else None,
            'oldest_report': all_reports[-1] if all_reports else None
        }

    @staticmethod
    def _generate_report_id(report_data: Dict) -> str:
        """
        Generate unique report ID
        """
        timestamp = datetime.now().isoformat()
        file1_name = report_data.get('file1', {}).get('name', 'file1')
        file2_name = report_data.get('file2', {}).get('name', 'file2')
        project_name = report_data.get('project_name', '')

        combined = f"{timestamp}_{file1_name}_{file2_name}_{project_name}"
        report_id = hashlib.md5(combined.encode()).hexdigest()[:12]

        return report_id

    def cleanup_old_reports(self, days: int = 30) -> int:
        """Delete reports older than specified days"""
        import time

        deleted_count = 0
        current_time = time.time()
        cutoff_time = current_time - (days * 86400)

        for filename in os.listdir(self.history_folder):
            if filename.endswith('.json'):
                report_path = os.path.join(self.history_folder, filename)
                file_time = os.path.getmtime(report_path)

                if file_time < cutoff_time:
                    os.remove(report_path)
                    deleted_count += 1

        return deleted_count
