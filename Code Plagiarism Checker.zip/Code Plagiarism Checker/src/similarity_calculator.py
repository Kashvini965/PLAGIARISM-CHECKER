"""
Similarity calculation and analysis module
"""

from typing import Dict, List
from src.plagiarism_detector import PlagiarismDetector
from src.file_parser import FileParser


class SimilarityCalculator:
    """Calculate similarity between code files"""

    def __init__(self):
        self.detector = PlagiarismDetector()
        self.parser = FileParser()

    def compare_files(self, file1_path: str, file2_path: str) -> Dict:
        """
        Compare two code files for similarity
        Returns comprehensive comparison results
        """
        # Validate files
        valid1, msg1 = self.parser.validate_file(file1_path)
        valid2, msg2 = self.parser.validate_file(file2_path)

        if not valid1 or not valid2:
            return {
                'error': True,
                'message': f"File validation failed: {msg1 if not valid1 else msg2}"
            }

        # Read files
        code1 = self.parser.read_file(file1_path)
        code2 = self.parser.read_file(file2_path)

        # Get file information
        file1_name, file1_ext, file1_size = self.parser.get_file_info(file1_path)
        file2_name, file2_ext, file2_size = self.parser.get_file_info(file2_path)

        # Detect plagiarism
        detection_result = self.detector.detect_plagiarism(code1, code2)

        return {
            'error': False,
            'file1': {
                'name': file1_name,
                'extension': file1_ext,
                'size_kb': file1_size,
                'language': self.parser.get_language(file1_path)
            },
            'file2': {
                'name': file2_name,
                'extension': file2_ext,
                'size_kb': file2_size,
                'language': self.parser.get_language(file2_path)
            },
            'analysis': detection_result,
            'recommendation': self._get_recommendation(detection_result['average_similarity'])
        }

    def compare_text(self, code1: str, code2: str, file1_name: str = "Code 1",
                     file2_name: str = "Code 2") -> Dict:
        """
        Compare two code snippets (text)
        Useful for comparing pasted code
        """
        if not code1 or not code2:
            return {
                'error': True,
                'message': "Both code snippets must be provided"
            }

        detection_result = self.detector.detect_plagiarism(code1, code2)

        return {
            'error': False,
            'file1': {'name': file1_name},
            'file2': {'name': file2_name},
            'analysis': detection_result,
            'recommendation': self._get_recommendation(detection_result['average_similarity'])
        }

    def batch_compare(self, code_snippets: List[Dict]) -> List[Dict]:
        """
        Compare multiple code snippets against each other
        code_snippets: list of {"name": str, "code": str}
        Returns list of pairwise comparison results
        """
        results = []

        for i in range(len(code_snippets)):
            for j in range(i + 1, len(code_snippets)):
                snippet1 = code_snippets[i]
                snippet2 = code_snippets[j]

                result = self.compare_text(
                    snippet1['code'],
                    snippet2['code'],
                    snippet1.get('name', f'Snippet {i+1}'),
                    snippet2.get('name', f'Snippet {j+1}')
                )

                results.append(result)

        return results

    @staticmethod
    def _get_recommendation(similarity_percentage: float) -> str:
        """Generate recommendation based on similarity percentage"""
        if similarity_percentage >= 90:
            return "VERY HIGH SIMILARITY - Almost certainly plagiarized"
        elif similarity_percentage >= 75:
            return "HIGH SIMILARITY - Likely plagiarized"
        elif similarity_percentage >= 60:
            return "MODERATE SIMILARITY - May be plagiarized"
        elif similarity_percentage >= 40:
            return "LOW SIMILARITY - Possibly coincidental similarity"
        else:
            return "VERY LOW SIMILARITY - Likely original"

    @staticmethod
    def get_similarity_color(similarity_percentage: float) -> str:
        """Get color code for similarity visualization"""
        if similarity_percentage >= 90:
            return "#d32f2f"  # Red
        elif similarity_percentage >= 75:
            return "#f57c00"  # Orange
        elif similarity_percentage >= 60:
            return "#fbc02d"  # Yellow
        elif similarity_percentage >= 40:
            return "#7cb342"  # Light Green
        else:
            return "#388e3c"  # Green
