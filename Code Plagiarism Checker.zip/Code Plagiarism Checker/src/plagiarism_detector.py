"""
Core plagiarism detection module using various algorithms
"""

import re
from typing import List, Tuple, Dict
from difflib import SequenceMatcher
from collections import Counter


class PlagiarismDetector:
    """Main class for detecting code plagiarism"""

    def __init__(self):
        self.min_similarity_threshold = 0.7

    def normalize_code(self, code: str) -> str:
        """
        Normalize code by removing comments, extra whitespace, and standardizing formatting
        """
        # Remove single-line comments
        code = re.sub(r'//.*', '', code)
        # Remove multi-line comments
        code = re.sub(r'/\*.*?\*/', '', code, flags=re.DOTALL)
        # Remove Python comments
        code = re.sub(r'#.*', '', code)
        # Remove extra whitespace
        code = re.sub(r'\s+', ' ', code).strip()
        return code

    def tokenize_code(self, code: str) -> List[str]:
        """
        Tokenize code into meaningful units
        """
        # Remove strings and comments
        normalized = self.normalize_code(code)
        # Split by whitespace and special characters
        tokens = re.findall(r'\b\w+\b|[(){}\[\];,.]', normalized)
        return tokens

    def calculate_similarity_ratio(self, code1: str, code2: str) -> float:
        """
        Calculate similarity ratio between two code snippets using SequenceMatcher
        Returns a value between 0 and 1, where 1 is identical
        """
        tokens1 = self.tokenize_code(code1)
        tokens2 = self.tokenize_code(code2)

        if not tokens1 or not tokens2:
            return 0.0

        # Use SequenceMatcher to find matching blocks
        matcher = SequenceMatcher(None, tokens1, tokens2)
        similarity = matcher.ratio()
        return similarity

    def calculate_jaccard_similarity(self, code1: str, code2: str) -> float:
        """
        Calculate Jaccard similarity (set-based similarity)
        Measures the size of intersection over union
        """
        tokens1 = set(self.tokenize_code(code1))
        tokens2 = set(self.tokenize_code(code2))

        if not tokens1 and not tokens2:
            return 1.0

        if not tokens1 or not tokens2:
            return 0.0

        intersection = len(tokens1 & tokens2)
        union = len(tokens1 | tokens2)

        return intersection / union if union > 0 else 0.0

    def calculate_cosine_similarity(self, code1: str, code2: str) -> float:
        """
        Calculate cosine similarity between code snippets
        Based on token frequency vectors
        """
        tokens1 = self.tokenize_code(code1)
        tokens2 = self.tokenize_code(code2)

        if not tokens1 or not tokens2:
            return 0.0

        # Create frequency vectors
        freq1 = Counter(tokens1)
        freq2 = Counter(tokens2)

        # Calculate dot product
        dot_product = sum(freq1[token] * freq2.get(token, 0) for token in freq1)

        # Calculate magnitudes
        magnitude1 = sum(count ** 2 for count in freq1.values()) ** 0.5
        magnitude2 = sum(count ** 2 for count in freq2.values()) ** 0.5

        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0

        return dot_product / (magnitude1 * magnitude2)

    def find_suspicious_portions(self, code1: str, code2: str) -> List[Dict]:
        """
        Find suspicious portions (matching segments) between two code snippets
        Returns a list of matching segments with positions and lengths
        """
        tokens1 = self.tokenize_code(code1)
        tokens2 = self.tokenize_code(code2)

        matches = []
        matcher = SequenceMatcher(None, tokens1, tokens2)

        for block in matcher.get_matching_blocks():
            if block.size > 2:  # Only consider blocks with more than 2 tokens
                match_info = {
                    'start1': block.a,
                    'start2': block.b,
                    'length': block.size,
                    'tokens': ' '.join(tokens1[block.a:block.a + block.size])
                }
                matches.append(match_info)

        return matches

    def detect_plagiarism(self, code1: str, code2: str) -> Dict:
        """
        Main detection method that combines multiple algorithms
        Returns comprehensive plagiarism detection results
        """
        # Calculate similarities using different methods
        sequence_similarity = self.calculate_similarity_ratio(code1, code2)
        jaccard_similarity = self.calculate_jaccard_similarity(code1, code2)
        cosine_similarity = self.calculate_cosine_similarity(code1, code2)

        # Average similarity
        average_similarity = (
            sequence_similarity + jaccard_similarity + cosine_similarity
        ) / 3

        # Find suspicious portions
        suspicious_portions = self.find_suspicious_portions(code1, code2)

        # Determine if plagiarism is detected
        is_plagiarized = average_similarity >= self.min_similarity_threshold

        return {
            'is_plagiarized': is_plagiarized,
            'average_similarity': round(average_similarity * 100, 2),
            'sequence_similarity': round(sequence_similarity * 100, 2),
            'jaccard_similarity': round(jaccard_similarity * 100, 2),
            'cosine_similarity': round(cosine_similarity * 100, 2),
            'suspicious_portions': suspicious_portions,
            'total_matches': len(suspicious_portions)
        }
