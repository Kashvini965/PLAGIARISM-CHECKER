"""
Content comparison module for detailed plagiarism detection
Provides line-by-line and segment-level comparison
"""

import re
from typing import Dict, List, Tuple
from difflib import SequenceMatcher, unified_diff


class ContentComparator:
    """Detailed content comparison with segment detection"""

    def __init__(self):
        self.min_segment_length = 3  # Minimum lines for a segment

    def compare_content_detailed(self, code1: str, code2: str) -> Dict:
        """
        Perform detailed content comparison
        Returns matching segments and line-by-line analysis
        """
        lines1 = code1.strip().split('\n')
        lines2 = code2.strip().split('\n')

        # Find matching blocks
        matching_blocks = self._find_matching_blocks(lines1, lines2)

        # Generate line-by-line comparison
        line_comparison = self._generate_line_comparison(lines1, lines2)

        # Extract matching segments
        segments = self._extract_segments(lines1, lines2, matching_blocks)

        return {
            'matching_blocks': matching_blocks,
            'line_comparison': line_comparison,
            'segments': segments,
            'total_matching_lines': len([l for l in line_comparison if l['status'] == 'match']),
            'total_lines_file1': len(lines1),
            'total_lines_file2': len(lines2),
            'match_percentage': self._calculate_match_percentage(line_comparison, lines1, lines2)
        }

    def _find_matching_blocks(self, lines1: List[str], lines2: List[str]) -> List[Dict]:
        """
        Find matching blocks between two code files
        Returns list of matching segments
        """
        matcher = SequenceMatcher(None, lines1, lines2)
        matching_blocks = []

        for block in matcher.get_matching_blocks():
            if block.size >= self.min_segment_length:
                matching_blocks.append({
                    'file1_start': block.a,
                    'file1_end': block.a + block.size,
                    'file2_start': block.b,
                    'file2_end': block.b + block.size,
                    'length': block.size,
                    'lines': lines1[block.a:block.a + block.size]
                })

        return sorted(matching_blocks, key=lambda x: x['length'], reverse=True)

    def _generate_line_comparison(self, lines1: List[str], lines2: List[str]) -> List[Dict]:
        """
        Generate line-by-line comparison
        """
        comparison = []
        matcher = SequenceMatcher(None, lines1, lines2)

        file1_idx = 0
        file2_idx = 0

        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == 'equal':
                for k in range(i2 - i1):
                    comparison.append({
                        'status': 'match',
                        'file1_line': i1 + k + 1,
                        'file2_line': j1 + k + 1,
                        'content': lines1[i1 + k],
                        'type': 'identical'
                    })
                file1_idx = i2
                file2_idx = j2
            elif tag == 'replace':
                for k in range(max(i2 - i1, j2 - j1)):
                    if i1 + k < i2:
                        comparison.append({
                            'status': 'replaced',
                            'file1_line': i1 + k + 1,
                            'file2_line': j1 + k + 1 if j1 + k < j2 else None,
                            'content': lines1[i1 + k],
                            'type': 'modified'
                        })
                    else:
                        comparison.append({
                            'status': 'added',
                            'file1_line': None,
                            'file2_line': j1 + k + 1,
                            'content': lines2[j1 + k],
                            'type': 'added'
                        })
                file1_idx = i2
                file2_idx = j2

        return comparison

    def _extract_segments(self, lines1: List[str], lines2: List[str], 
                         matching_blocks: List[Dict]) -> List[Dict]:
        """
        Extract and structure matching segments
        """
        segments = []

        for block in matching_blocks:
            segment = {
                'file1_start_line': block['file1_start'] + 1,
                'file1_end_line': block['file1_end'],
                'file2_start_line': block['file2_start'] + 1,
                'file2_end_line': block['file2_end'],
                'length': block['length'],
                'content': '\n'.join(block['lines']),
                'similarity': 100  # Exact match within segment
            }
            segments.append(segment)

        return segments

    def _calculate_match_percentage(self, line_comparison: List[Dict], 
                                   lines1: List[str], lines2: List[str]) -> float:
        """
        Calculate percentage of matching lines
        """
        if not lines1 or not lines2:
            return 0.0

        matching_lines = len([l for l in line_comparison if l['status'] == 'match'])
        total_lines = max(len(lines1), len(lines2))

        return round((matching_lines / total_lines) * 100, 2) if total_lines > 0 else 0.0

    def generate_diff_html(self, code1: str, code2: str, filename1: str = "File 1", 
                          filename2: str = "File 2") -> str:
        """
        Generate HTML diff view for side-by-side comparison
        """
        lines1 = code1.split('\n')
        lines2 = code2.split('\n')
        
        comparison = self.compare_content_detailed(code1, code2)
        line_comp = comparison['line_comparison']

        html = f"""
        <div class="diff-container">
            <div class="diff-header">
                <div class="diff-file">{filename1}</div>
                <div class="diff-file">{filename2}</div>
            </div>
            <div class="diff-content">
                <table class="diff-table">
                    <tbody>
        """

        # Group lines by file
        file1_lines = {}
        file2_lines = {}
        
        for item in line_comp:
            if item['file1_line']:
                file1_lines[item['file1_line']] = item
            if item['file2_line']:
                file2_lines[item['file2_line']] = item

        # Render diff
        max_lines = max(len(lines1), len(lines2))
        for i in range(max_lines):
            line1_num = i + 1
            line2_num = i + 1
            
            line1_content = lines1[i] if i < len(lines1) else ""
            line2_content = lines2[i] if i < len(lines2) else ""
            
            line1_class = "match" if line1_num in file1_lines and file1_lines[line1_num]['status'] == 'match' else ""
            line2_class = "match" if line2_num in file2_lines and file2_lines[line2_num]['status'] == 'match' else ""
            
            html += f"""
                    <tr>
                        <td class="line-number">{line1_num if line1_num <= len(lines1) else ""}</td>
                        <td class="line-content {line1_class}"><code>{self._escape_html(line1_content)}</code></td>
                        <td class="line-number">{line2_num if line2_num <= len(lines2) else ""}</td>
                        <td class="line-content {line2_class}"><code>{self._escape_html(line2_content)}</code></td>
                    </tr>
            """

        html += """
                    </tbody>
                </table>
            </div>
        </div>
        """
        return html

    @staticmethod
    def _escape_html(text: str) -> str:
        """Escape HTML special characters"""
        text = text or ""
        return (text.replace('&', '&amp;')
                    .replace('<', '&lt;')
                    .replace('>', '&gt;')
                    .replace('"', '&quot;')
                    .replace("'", '&#39;'))
